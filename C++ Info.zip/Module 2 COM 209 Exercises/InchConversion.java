import java.util.Scanner;
public class InchConversion
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter amount of inches: ");
        int inches = input.nextInt();
        feet(inches);
        yards(inches);
    }
    public static void feet(int inches)
    {
        int totalInches = inches / 12;
        System.out.println("Total Feet: " + totalInches);
    }
    public static void yards(int inches)
    {
        int totalInches = inches / 36;
        System.out.print("Total Yards: " + totalInches);
    }
}