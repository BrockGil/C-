import java.util.Scanner;
public class PaintCalculator
{
	public static void main(String[] args) 
	{
	    Scanner input = new Scanner(System.in);
	    
		System.out.print("Length: ");
		int length = input.nextInt();
		System.out.print("Width: ");
		int width = input.nextInt();
		System.out.print("Height: ");
		int height = input.nextInt();
		
		int area = totalArea(length, width, height);
		
		gallonsNeeded(area);
		totalPrice(length, width, height);
	}
	
	public static int totalArea (int l, int w, int h)
	{
	    int ceilingArea = l * w;
	    int wallArea = w * h;
	    int total = ceilingArea + wallArea;
	    System.out.println("Your square footage is " + total + ".");
	    return total; 
	}
	
	public static double gallonsNeeded (int a)
	{
	    int gallons = (a / 350) + 1;
	    System.out.println(gallons + " gallons are needed to complete this job.");
	    return gallons;
	}
	public static void totalPrice (int l, int w, int h)
	{
	    int ceilingArea = l * w;
	    int wallArea = w * h;
	    int total = ceilingArea + wallArea;
	    double price = 32 * (total / 350 + 1);
	    System.out.print("At $32.00 a gallon, your price is $");
	    System.out.printf("%.2f", price);
	}
}
