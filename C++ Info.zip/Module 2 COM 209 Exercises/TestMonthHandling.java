import java.time.*;

public class TestMonthHandling 
{
	public static void main(String [] args)
	{	
		
		LocalDate jan = LocalDate.of(2020, 1, 31);
		LocalDate dec = LocalDate.of(2020, 12, 31);
		System.out.println("Original Dates: ");
		System.out.println(jan);
		System.out.println(dec);
		sep();
		System.out.println("One month added:");
		System.out.println(jan.plusMonths(1));
		System.out.println(dec.plusMonths(1));
		sep();
		System.out.println("Two Months Added:");
		System.out.println(jan.plusMonths(2));
		System.out.println(dec.plusMonths(2));
		sep();
		System.out.println("Three Months Added:");
		System.out.println(jan.plusMonths(3));
		System.out.println(dec.plusMonths(3));
		
	}	
	public static void sep()
	{
		System.out.println("------------------------------------");
	}
}

