#include <iostream>
#include<string>
using namespace std;

int main()
{
   string city = "";
   string state = "";
   string zip = "";
   string allTogether = "";

       cout << "Please Enter City: ";
       cin >> city;
       if(city == "-")
       {
           cout << "Program terminated based on sentinel value";
           exit(0);
       }//end if
       cout << "Please Enter State: ";
       cin >> state;
       if(state == "-")
       {
           cout << "Program terminated based on sentinel value";
           exit(0);
       }//end if
       cout << "Please Enter Zip: ";
       cin >> zip;
       if(zip == "-")
       {
           cout << "Program terminated based on sentinel value";
           exit(0);
       }//end if
       allTogether = city + ", " + state + "  " + zip;
       cout << allTogether << endl;
 
}