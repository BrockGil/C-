#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

double regularPay (double total, double hours, double hourlyPay);
void overTime (double hourlyPay, double hours);
double doubleTime (double hourlyPay, double hours, double total);

int main()
{
   double hours;
   double hourlyPay;
   double gross;
   
   cout << "Enter hours: ";
   cin >> hours;
   if (hours < 0)
   {
       cout << "Negative numbers terminate your program!";
       exit(0);
   }//end if
   cout << "Payrate: ";
   cin >> hourlyPay;
   if (hourlyPay < 0)
   {
       cout << "Negative numbers terminate your program!";
       exit(0);
   }//end if 
   
        if (hours < 38)
        {
            cout << regularPay(hours, hourlyPay, gross);
        }
        else if (hours < 51)
        {
           overTime (hourlyPay, hours);
        }
        else if (hours > 50)
        {
           cout << doubleTime (hourlyPay, hours, gross);
        }//end if
        
    return 0;
}


double regularPay (double hours, double hourlyPay, double total)
{
    total = hours * hourlyPay;
    return total;
}// end regularPay

void overTime (double hourlyPay, double hours)
{
    cout << (hourlyPay * 37) + (1.5 * hourlyPay) * (hours - 37);
}// end overTime

double doubleTime (double hourlyPay, double hours, double total)
{
    total = (hourlyPay * 37) + ((1.5 * hourlyPay) * 13) +  ((2 * hourlyPay) * (hours - 50));
    return total;
    
}// end doubleTime
