#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int secondPower (int i); 
int cubedPower (int i);

int main()
{
    int i;
    
      cout << " Number   Square    Cube" << endl;
    for (i = 10; i < 14; i++)
    {
        cout << "  " << i << "       " <<  secondPower (i) << "      " << cubedPower (i) << endl;
    }
    
    return 0;
}

int secondPower (int i) 

{
    return pow (i, 2);
}

int cubedPower (int i)
{
    return pow (i, 3);
}
