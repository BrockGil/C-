#include <iostream>
using namespace std;

int main ()
{
	int numberOfRegistrants;

	cout << "Enter number of registrants: ";
	cin >> numberOfRegistrants;
	
if (numberOfRegistrants >= 1 && numberOfRegistrants <= 5)
	cout << numberOfRegistrants * 125;
// end if
if (numberOfRegistrants >= 6 && numberOfRegistrants <= 20)
	cout << numberOfRegistrants * 100;
//end if
if (numberOfRegistrants >= 21)
	cout << numberOfRegistrants * 75;
else if(numberOfRegistrants <= 0)
	cout << "Error. Enter valid number.";
//end if

return 0;
}

