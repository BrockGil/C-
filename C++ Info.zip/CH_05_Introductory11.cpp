#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int numberOfPounds = 0;
	double pricePerPound = 0.0;
	char tax = ' ';

	cout << "Pounds: ";
	cin >> numberOfPounds;
	cout << "Price Per Pound: ";
	cin >> pricePerPound;
	cout << "Should sales tax be charged? Type 'y' or 'n': ";
	cin >> tax;
   
	if (tax == 'y')
 	{
    	cout << "Price: " << setprecision(4) << (pricePerPound * numberOfPounds) * 0.035 + (pricePerPound * numberOfPounds);
 	}  
	else 
 	{  
    	cout << "Price: " << setprecision(4) << pricePerPound * numberOfPounds;  
 	} //end if    
	 
    	 
	return 0;
}

