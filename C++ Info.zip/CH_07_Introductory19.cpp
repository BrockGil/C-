#include <iostream>
#include <iomanip>
using namespace std;

int main ()
{
    int score1;
    
    cout << "Enter student's midterm score: ";
    cin >> score1;
    
    while (score1 > 200 || score1 < 0)
    {
        cout << "Score can not be above 200 or below zero. Please enter valid score." << endl;
        cout << "Enter student's midterm score: ";
        cin >> score1;
    }//end while
    
    int score2;
    
    cout << "Enter student's final exam score: ";
    cin >> score2;
    
     while (score2 > 200 || score2 < 0)
    {
        cout << "Score can not be above 200 or below zero. Please enter valid score." << endl;
        cout << "Enter student's final exam score: ";
        cin >> score2;
    }//end while

while (score1 + score2 !=- 1)
{
    if (score1 + score2 <= 400 && score1 + score2 >= 360)
    {
        cout << "Grade: A. Total scores equal: " << score1 + score2 << endl;
    }
    
    else if (score1 + score2 < 360 && score1 + score2 >= 320)
    {
        cout << "Grade: B. Total scores equal: " << score1 + score2 << endl;
    }
    
    else if (score1 + score2 < 320 && score1 + score2 >= 280)
    {
        cout << "Grade: C. Total scores equal: " << score1 + score2 << endl;
    }
    
    else if (score1 + score2 < 280 && score1 + score2 >= 240)
    {
        cout << "Grade: D. Total scores equal: " << score1 + score2 << endl;
    }
    
    else if (score1 + score2 < 240)
    {
        cout << "Grade: F. Total scores equal: " << score1 + score2 << endl;
    }
    
     cout << "Enter student's midterm score: ";
    cin >> score1;
        while (score1 > 200 || score1 < 0)
        {
        cout << "Score can not be above 200 or below zero. Please enter valid score." << endl;
        cout << "Enter student's midterm score: ";
        cin >> score1;
        }//end while
        
    cout << "Enter student's final exam score: ";
    cin >> score2;
        while (score2 > 200 || score2 < 0)
        {
        cout << "Score can not be above 200 or below zero. Please enter valid score." << endl;
        cout << "Enter student's final exam score: ";
        cin >> score2;
        }//end while
}

return 0;

}