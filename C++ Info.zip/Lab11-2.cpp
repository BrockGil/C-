#include <iostream>
#include <iomanip>
using namespace std;

//Prototypes
double getAverage (double times[], int numElements);
double getLowest (double times[], int numElements);

int main ()
{
    double finishTimes [5] = {0.0};
    double avgTime = 0.0;
    double lowestTime = 0.0;
    
    //enter finish times
    for (int x = 0; x < 5; x++)
    {
        cout << "Time for race " << x + 1 << ": ";
        cin >> finishTimes [x];
    }//end for
    
    avgTime = getAverage(finishTimes, 5);
    lowestTime = getLowest(finishTimes, 5);
    
    
    cout << "Average 5K finish time: " << avgTime << endl;
    cout << "Lowest 5K finish time: " << lowestTime << endl;
    
}//end main

//*****Function Definitions*****
double getAverage(double times [], int numElements)
{
    double total = 0.0;
    
    for (int x = 0; x < numElements; x++)
        total += times[x];
        return total / numElements;
}// end Function

double getLowest(double times [], int numElements)
{
    double lowest = times [0];
    for (int x = 1; x < numElements; x ++)
        if (times [x] < lowest)
            lowest = times [x];
            
            return lowest;
}









