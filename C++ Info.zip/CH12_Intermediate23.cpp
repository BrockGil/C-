#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    int temperatures[7][2];
    
    for (int row = 0; row < 7; row++)
    {
        cout << "Enter highest temperature first, then the lowest: ";
        for (int column = 0; column < 2; column++)
        cin >> temperatures[row][column];
    }
    cout << "       Highest  Lowest" << endl;
    for (int row = 0; row < 7; row++)
    {
        cout << "Day " << row + 1 << ":  "; // dude!!!! row + 1!!!!!!!!!
        for (int column = 0; column < 2; column++)
        {    
            cout << temperatures[row][column] << " ";
        }
    cout << endl;
    }
 
   double sum = 0;
    
    for(int x = 0; x < 7; x++)
    {
        sum += temperatures[x][0];
    }
    cout << "Highest average temperature: " << setprecision(3) << sum / 7.0 << endl; 
    
    int lowestA = 0;
    
     for(int x = 0; x < 7; x++)
    {
        lowestA += temperatures[x][1];
    }
    cout << "Lowest average temperature: " << setprecision(3) << lowestA / 7.0 << endl; 
}




