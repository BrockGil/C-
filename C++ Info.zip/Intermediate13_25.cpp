#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    string input = "";
    string reverse = "";
    int i;
    
    cout << "Enter Input: ";
    getline (cin, input);
    
    for(int i = input.length() - 1; i >=0; --i)
    {
        reverse += input[i];
    }
    cout << "Input reversed is: " << reverse;
    return 0;
}

