#include <iostream>
using namespace std;
int main()
{
int smallPizzasSold = 0;
int mediumPizzasSold = 0;
int largePizzasSold = 0;
int familyPizzasSold = 0;
cout << "Enter amount of small pizzas: ";
cin >> smallPizzasSold; 
cout << "Enter amount of medium pizzas: ";
cin >> mediumPizzasSold;
cout << "Enter amount of large pizzas: ";
cin >> largePizzasSold;
cout << "Enter amount of family pizzas: ";
cin >> familyPizzasSold;

double total = smallPizzasSold + mediumPizzasSold + largePizzasSold + familyPizzasSold;

cout << "Total pizzas sold: " << total << endl;

double smallPizzaPercentage = smallPizzasSold / total;
double mediumPizzaPercentage = mediumPizzasSold / total;
double largePizzaPercentage = largePizzasSold / total;
double familyPizzaPercentage = familyPizzasSold / total;
cout << "Total percentage of small pizzas: ";
cout << smallPizzaPercentage << endl; 
cout << "Total percentage of medium pizzas: ";
cout << mediumPizzaPercentage << endl; 
cout << "Total percentage of large pizzas: ";
cout << largePizzaPercentage << endl;
cout << "Total percentage of family pizzas: ";
cout << familyPizzaPercentage <<endl; 

}