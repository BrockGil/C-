#include <iostream>
#include<string>
using namespace std;

int main()
{
    string regionCode = "";
    
    cout << "Please enter Region Code. 1st character should be A or B. The other characters should be numbers." << endl << "Enter region code: ";
    getline (cin, regionCode); // Just Practicing
    
    while (regionCode != "-1")
    {
        if (regionCode.length() > 3)
        {
            cout << "Enter 3 characters." << endl << "Please enter Region Code: ";
            cin >> regionCode;
        }//end if
        if (regionCode.length() < 3)
        {
            cout << "Enter 3 characters." << endl << "Please enter Region Code: ";
            cin >> regionCode;
        }//end if
        if (regionCode.at(0) == 'A' || regionCode.at(0) == 'B')
        {
            cout << regionCode << endl; 
            cin >> regionCode;
        }
        else
        {    
            cout << "Please enter correct characters." << endl;
            cin >> regionCode;
        }//end if
    }
}
