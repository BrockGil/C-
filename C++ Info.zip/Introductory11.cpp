#include <iostream>

using namespace std;

int main()
{
double initialBalance = 0.0;
double totalDeposits = 0.0;
double totalWithdrawals = 0.0;
double totalBalance;
cout << "Enter the initial Balance: ";
cin >> initialBalance;
cout << "Enter total deposits: ";
cin >> totalDeposits;
cout << "Enter total withdrawals: ";
cin >> totalWithdrawals; 

totalBalance = (totalDeposits - totalWithdrawals) + initialBalance;

cout << totalBalance;

}
