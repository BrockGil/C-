#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

int sumOfNums (int a, int b); // this is a prototype. Needed to be declared before the main function. 

int main()
{   
    int a;
    int b;
    
    cout << "Enter int a: ";
    cin >> a;
    cout << "Enter int b: ";
    cin >> b;
    
    cout << sumOfNums (a , b);
}

int sumOfNums (int a, int b) // this is the value returning function.
{
    int answer = a * b; 
    
}
// Basic calling a function 
