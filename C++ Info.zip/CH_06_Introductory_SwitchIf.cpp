#include <iostream>
using namespace std;

int main()
{
    int x;

    cout << "How many registrants: ";
    cin >> x; 

switch (x)
{
case 1:
case 2:
case 3:
case 4:
case 5:
    cout << "Amount owed: " << (125 * x);
break; 

case 6:
case 7:
case 8:
case 9:
case 10:
case 11:
case 12:
case 13:
case 14:
case 15:
case 16:
case 17:
case 18:
case 19:
case 20:
    cout << "Amount owed: " << (100 * x);
break;

}

/* end switch */


    if (x <= 0)
    cout << "Error. Enter a valid number";  
    // end if
    if (x >= 21)
    cout << (x * 75);
    //end if
}


