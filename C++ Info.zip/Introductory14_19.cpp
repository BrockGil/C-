#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    double payrollAmount = 0.0;
    ofstream outPayRoll;
    
    outPayRoll.open("Payroll.txt", ios::app);
    while (payrollAmount != -1)
    {
        cout << "Please enter payroll amount: ";
        cin >> payrollAmount;
        if (payrollAmount == -1)
        {
            cout << "-1 exits the program.";
            exit(0);
        }
        else
        outPayRoll << fixed << setprecision(2) << payrollAmount << endl;
    }
    outPayRoll.close();

    return 0;
}
