#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
    
    double salary = 0.0;
    double copySalary = 0;
    cout << "Enter salary: "; 
    cin >> salary; 
 
    for (double rate = 0.03; rate < 0.07; rate += 0.01)
    {
        cout << "While rate is " << rate << endl;
        copySalary = salary; //refresher
        for (int years = 0; years < 4; years++)
        {
                
            cout << "Year " << years << ": " << copySalary << endl;
            copySalary += copySalary * rate;
            
        }
        cout << endl;
    }
   
 
}
