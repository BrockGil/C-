#include <iostream>

using namespace std;

int getLowest(int numArray[], int numElements);

int main()

{       
    int numbers[4] = {13, 2, 40, 25}; // array declaration
    
    cout << "The lowest number in the array is "
    << getLowest (numbers, 4) << "." << endl; // do not need the [] when calling the array

    return 0;
}

int getLowest (int numArray[], int numElements)
{
    //assign first element's value to the low variable
    int low = numArray[0];
    
    //begin search with second element
    for (int sub = 1; sub < numElements; sub++)
        if(numArray[sub] < low) 
        low = numArray[sub];
        
        return low;
}