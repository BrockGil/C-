#include <iostream>
using namespace std;

int main()
{
    int myArray[5];
    
    for (int x = 0; x < 5; x++)
        {
            cout << "Enter number: ";
            cin >> myArray[x];
        }
    
    cout << myArray[3]; // displays what number was entered by using the subdirectory number associated with place "[3]"
        
    return 0;
}
