#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    double priceAmount = 0.0;
    ofstream outPayRoll;
    
    outPayRoll.open("Prices.txt", ios::app);
    while (priceAmount != -1)
    {
        cout << "Please enter prices: ";
        cin >> priceAmount;
        if (priceAmount == -1)
        {
            cout << "-1 exits the program.";
            exit(0);
        }
        else
        outPayRoll << fixed << setprecision(2) << priceAmount << endl;
    }
    outPayRoll.close();

    return 0;
}
