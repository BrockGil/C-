#include <iostream>
#include <iomanip>

using namespace std;

int main ()
{
    
	double salary = 0.0;

	cout << "Enter salary: "; 
	cin >> salary; 

while (salary != -1)
{
    for (double rate = 0.03; rate < 0.07; rate += 0.01)
    {
        
        cout << rate << endl;
            for (int years = 1; years < 4; years++)
	     
            cout << "Year " << years << ": " << rate * salary + salary<< endl;

    }
break;
}

}
