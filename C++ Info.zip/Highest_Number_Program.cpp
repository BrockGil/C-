#include <iostream>

using namespace std;

int getHighest(int numArray[], int numElements);

int main()

{       
    int numbers[4] = {13, 2, 40, 25}; // array declaration
    
    cout << "The highest number in the array is "
    << getHighest (numbers, 4) << "." << endl; // do not need the [] when calling the array

    return 0;
}

int getHighest (int numArray[], int numElements)
{
    //assign first element's value to the high variable
    int high = numArray[0];
    
    //begin search with second element
    for (int sub = 1; sub < numElements; sub++)
        if(numArray[sub] > high)
        high = numArray[sub];
        
        return high;
}